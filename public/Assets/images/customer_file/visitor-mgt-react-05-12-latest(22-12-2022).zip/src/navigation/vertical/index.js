// ** Navigation imports
import apps from "./apps";

// ** Merge & Export
export default [...apps];
