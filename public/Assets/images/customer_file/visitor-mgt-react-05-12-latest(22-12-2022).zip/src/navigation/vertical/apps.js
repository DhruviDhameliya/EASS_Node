// ** Icons Import
import { Home, PlusCircle, Users, Circle, Phone } from "react-feather";
import secureLocalStorage from "react-secure-storage";
let user = JSON.parse(secureLocalStorage.getItem("userData"));

let common_view = [
  {
    id: "dashboard",
    title: "Dashboard",
    icon: <Home size={20} />,
    navLink: "/dashboard",
  },
  {
    id: "event",
    title: "Event",
    icon: <PlusCircle size={20} />,
    navLink: "/event",
  },
];

const staff = {
  id: "staff",
  title: "Staff",
  icon: <Users size={12} />,
  navLink: "/staff",
};

const data = {
  id: "data",
  title: "Data",
  icon: <Phone size={12} />,
  navLink: "/data",
};

if (user?.u_type == 0) {
  common_view.push(staff);
  common_view.push(data);
}

export default common_view;

// export default [
//   {
//     id: "dashboard",
//     title: "Dashboard",
//     icon: <Home size={20} />,
//     navLink: "/dashboard",
//   },
//   {
//     id: "event",
//     title: "Event",
//     icon: <PlusCircle size={20} />,
//     navLink: "/event",
//   },
//   {
//     id: "staff",
//     title: "Staff",
//     icon: <Users size={12} />,
//     navLink: "/staff",
//   },
// ];
