import { lazy } from "react";

const DashboardEvent = lazy(() => import("../../views/pages/event/event"));

const Event = [
  {
    path: "/event",
    element: <DashboardEvent />,
  },
];

export default Event;
