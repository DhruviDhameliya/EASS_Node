import { lazy } from "react";

const DashboardStaff = lazy(() => import("../../views/staff/staff"));

const Staff = [
  {
    path: "/staff",
    element: <DashboardStaff />,
  },
];

export default Staff;
