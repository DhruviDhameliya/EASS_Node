// ** React Imports
import { lazy } from "react";
import { Navigate } from "react-router-dom";

const Dashboard = lazy(() => import("../../views/pages/dashboard/dashboard"));
const Event = lazy(() => import("../../views/pages/event/event"));
const EventDashboard = lazy(() =>
  import("../../views/pages/event/eventdashboard")
);

const EventCheckIn = lazy(() => import("../../views/pages/event/eventcheckin"));

const Staff = lazy(() => import("../../views/pages/staff/staff"));
const Register = lazy(() =>
  import("../../views/pages/authentication/RegisterBasic")
);
const ForgotPassword = lazy(() =>
  import("../../views/pages/authentication/ForgotPasswordBasic")
);
const SubmitOtp = lazy(() =>
  import("../../views/pages/authentication/TwoStepsBasic")
);

const Data = lazy(() => import("../../views/pages/Data/data"));

import secureLocalStorage from "react-secure-storage";
let user = JSON.parse(secureLocalStorage.getItem("userData"));

const staff = {
  path: "/staff",
  element: <Staff />,
};

const data = {
  path: "/data",
  element: <Data />,
};

const TlsRoute = [
  {
    element: <Dashboard />,
    path: "/dashboard",
    meta: {
      appLayout: true,
      className: "email-application",
    },
  },
  {
    path: "/event",
    element: <Event />,
  },
  {
    path: "/eventdashboard",
    element: <EventDashboard />,
  },
  {
    path: "/eventcheckin",
    element: <EventCheckIn />,
  },
  {
    path: "/register",
    element: <Register />,
  },
  {
    path: "/forgotpassword",
    element: <ForgotPassword />,
  },
  {
    path: "/submitotp",
    element: <SubmitOtp />,
  },
];

if (user?.u_type == 0) {
  TlsRoute.push(staff);
  TlsRoute.push(data);
}

// user?.u_type == 0 ? TlsRoute.push(staff) : null;

export default TlsRoute;
