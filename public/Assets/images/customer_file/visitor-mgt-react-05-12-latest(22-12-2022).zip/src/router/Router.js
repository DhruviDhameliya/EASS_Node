// ** Router imports
import { lazy } from "react";

// ** Router imports
import { useRoutes, Navigate } from "react-router-dom";

// ** Layouts
import BlankLayout from "@layouts/BlankLayout";

// ** Hooks Imports
import { useLayout } from "@hooks/useLayout";

// ** Utils
import { getUserData, getHomeRouteForLoggedInUser } from "../utility/Utils";

// ** GetRoutes
import { getRoutes } from "./routes";

// ** Components
const Error = lazy(() => import("../views/pages/misc/Error"));
const Login = lazy(() => import("../views/pages/authentication/Login"));
const NotAuthorized = lazy(() => import("../views/pages/misc/NotAuthorized"));
const Registersbasic = lazy(() =>
  import("../views/pages/authentication/RegisterBasic")
);
const Mobileregister = lazy(() =>
  import("../views/pages/authentication/Mobileregister")
);
const ForgotPassword = lazy(() =>
  import("../views/pages/authentication/ForgotPasswordBasic")
);
const Submitotp = lazy(() =>
  import("../views/pages/authentication/TwoStepsBasic")
);
const GenerateQrCode = lazy(() => import("../views/pages/QRcode/qrcode"));
const RegisterQrCode = lazy(() =>
  import("../views/pages/RegisterQrCode/registerQrCode")
);
const InvitationCard = lazy(() =>
  import("../views/pages/Invitation/invitation")
);

const StallPost = lazy(() => import("../views/pages/Post/stallpost"));

const Evetnnotfound = lazy(() =>
  import("../views/pages/evetnnotfound/evetnnotfound")
);

const Router = () => {
  // ** Hooks
  const { layout } = useLayout();

  const allRoutes = getRoutes(layout);
  const getHomeRoute = () => {
    const user = getUserData();
    if (user) {
      return getHomeRouteForLoggedInUser(user.role);
    } else {
      return "/login";
    }
  };

  const routes = useRoutes([
    {
      path: "/",
      index: true,
      element: <Navigate replace to={getHomeRoute()} />,
    },
    {
      path: "/login",
      element: <BlankLayout />,
      children: [{ path: "/login", element: <Login /> }],
    },
    {
      path: "/register/:eventURL",
      element: <BlankLayout />,
      children: [{ path: "/register/:eventURL", element: <Registersbasic /> }],
    },
    {
      path: "/mobileregistered/:eventURL",
      element: <BlankLayout />,
      children: [
        { path: "/mobileregistered/:eventURL", element: <Mobileregister /> },
      ],
    },
    {
      path: "/forgotpassword",
      element: <BlankLayout />,
      children: [{ path: "/forgotpassword", element: <ForgotPassword /> }],
    },
    {
      path: "/verifyotp/:eventURL",
      element: <BlankLayout />,
      children: [{ path: "/verifyotp/:eventURL", element: <Submitotp /> }],
    },
    {
      path: "/visitingpass/:eventURL",
      element: <BlankLayout />,
      children: [
        { path: "/visitingpass/:eventURL", element: <GenerateQrCode /> },
      ],
    },
    {
      path: "/registerqrcode/:eventURL",
      element: <BlankLayout />,
      children: [
        { path: "/registerqrcode/:eventURL", element: <RegisterQrCode /> },
      ],
    },
    {
      path: "/invitation/:eventURL",
      element: <BlankLayout />,
      children: [
        { path: "/invitation/:eventURL", element: <InvitationCard /> },
      ],
    },
    {
      path: "/post/:eventURL",
      element: <BlankLayout />,
      children: [{ path: "/post/:eventURL", element: <StallPost /> }],
    },
    {
      path: "/evetnnotfound",
      element: <BlankLayout />,
      children: [{ path: "/evetnnotfound", element: <Evetnnotfound /> }],
    },
    {
      path: "/auth/not-auth",
      element: <BlankLayout />,
      children: [{ path: "/auth/not-auth", element: <NotAuthorized /> }],
    },
    {
      path: "*",
      element: <BlankLayout />,
      children: [{ path: "*", element: <Evetnnotfound /> }],
    },
    ...allRoutes,
  ]);

  return routes;
};

export default Router;
