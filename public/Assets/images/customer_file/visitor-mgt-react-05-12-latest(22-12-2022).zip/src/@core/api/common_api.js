import Request from ".";

import { ApiRoutes } from "../constants";

const OtpRequest = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.OTP, formdata);
    return res?.data;
  } catch (error) {
    throw error;
  }
};
const getAllRefunddata = async (u_id, page, perPage) => {
  try {
    const result = await Request.get(
      ApiRoutes.GETALLREFUNDDATA + "/" + u_id + "/" + page + "/" + perPage
    );
    return result?.data;
  } catch (error) {
    throw error;
  }
};
const getnotes = async (uid) => {
  try {
    const res = await Request.get(ApiRoutes.GETNOTES + "/" + 2);
    return res?.data;
  } catch (error) {
    throw error;
  }
};

const LoginRequest = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.LOGIN, formdata);
    return res;
  } catch (error) {
    throw error;
  }
};

const VisitorRegister = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.VISITORREGISTER, formdata);
    return res;
  } catch (error) {
    throw error;
  }
};

const VisitorConfirm = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.VISITORCONFIRM, formdata);
    return res;
  } catch (error) {
    throw error;
  }
};

const insertEvent = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.INSERTEVENT, formdata);
    return res;
  } catch (error) {
    throw error;
  }
};

const getallEvent = async () => {
  try {
    const res = await Request.get(ApiRoutes.GETALLEVENT);
    return res?.data;
  } catch (error) {
    throw error;
  }
};

const updateEvent = async (fndata) => {
  try {
    const res = await Request.post(ApiRoutes.UPDATEEVENT, fndata);
    return res;
  } catch (error) {
    throw error;
  }
};

const deleteeventbyurl = async (url) => {
  try {
    const res = await Request.get(ApiRoutes.DELETEEVENT + "/" + url);
    return res;
  } catch (error) {
    throw error;
  }
};
const geteventbytitle = async (url) => {
  try {
    const res = await Request.get(ApiRoutes.GETEVENTBYTITLE + "/" + url);
    return res;
  } catch (error) {
    throw error;
  }
};
const resendVisitorOTP = async (fndata) => {
  try {
    const res = await Request.post(ApiRoutes.RESENDVISITOROTP, fndata);
    return res;
  } catch (error) {
    throw error;
  }
};

const InsertMobileRegister = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.INSERTMOBILEREGISTER, formdata);
    return res;
  } catch (error) {
    throw error;
  }
};

const getEventStatics = async (e_id) => {
  try {
    const res = await Request.get(ApiRoutes.EVENTSTATICS + "/" + e_id);
    return res;
  } catch (error) {
    throw error;
  }
};

const insertStaff = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.INSERTSTAFF, formdata);
    return res;
  } catch (error) {
    throw error;
  }
};

const getallStaff = async () => {
  try {
    const res = await Request.get(ApiRoutes.GETALLSTAFF);
    return res?.data;
  } catch (error) {
    throw error;
  }
};

const deletestaff = async (id) => {
  try {
    const res = await Request.get(ApiRoutes.DELETESTAFF + "/" + id);
    return res;
  } catch (error) {
    throw error;
  }
};

const assignevent = async (fndata) => {
  try {
    const res = await Request.post(ApiRoutes.ASSIGNEVENT, fndata);
    return res;
  } catch (error) {
    throw error;
  }
};

const visitorcheckin = async (fndata) => {
  try {
    const res = await Request.post(ApiRoutes.VISITORCHECKIN, fndata);
    // console.log("res :>> ", res);
    return res;
  } catch (error) {
    throw error;
  }
};

const getallocatedEvent = async () => {
  try {
    const res = await Request.get(ApiRoutes.GETALLOCATEDEVENT);
    return res?.data;
  } catch (error) {
    throw error;
  }
};

const insertData = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.INSERTDATA, formdata);
    return res;
  } catch (error) {
    throw error;
  }
};

const getNumberData = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.GETNUMBERDATA, formdata);
    return res?.data;
  } catch (error) {
    throw error;
  }
};

const deleteData = async (id) => {
  try {
    const res = await Request.get(ApiRoutes.DELETEDATA + "/" + id);
    return res;
  } catch (error) {
    throw error;
  }
};

const visitorData = async (formdata) => {
  try {
    const res = await Request.post(ApiRoutes.GETVISITORLIST, formdata);
    return res.data.data;
  } catch (error) {
    throw error;
  }
};

export {
  OtpRequest,
  getAllRefunddata,
  getnotes,
  LoginRequest,
  VisitorRegister,
  VisitorConfirm,
  insertEvent,
  getallEvent,
  updateEvent,
  deleteeventbyurl,
  geteventbytitle,
  resendVisitorOTP,
  InsertMobileRegister,
  getEventStatics,
  insertStaff,
  getallStaff,
  deletestaff,
  assignevent,
  visitorcheckin,
  getallocatedEvent,
  insertData,
  getNumberData,
  deleteData,
  visitorData,
};
