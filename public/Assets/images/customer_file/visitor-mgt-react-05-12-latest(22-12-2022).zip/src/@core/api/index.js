import Axios from "axios";
import { ApiRoutes } from "../constants";

import secureLocalStorage from "react-secure-storage";
// import CryptoJS from "crypto-js";
import { handleLogout } from "../../utility/Utils";

export const axios = Axios.create({
  rejectUnauthorized: false, // (NOTE: this will disable client verification)
  baseURL: ApiRoutes.API_HOSTNAME,
  timeout: 1000000000,
  responseType: "json",
});

axios.interceptors.request.use(
  async (config) => {
    config.headers = {
      Accept: "application/json , */*",
      "Content-Type": "application/json",
      // Authorization: `Bearer U2FsdGVkX1+xp44lcG2yZCZstdoCj02pygMgiiC2I01+rgwKFhxoAMUtYKf6g3B22HjLym8m4Vm0gzn2nMqbVA==`,
      Authorization: `Bearer ${JSON.parse(
        secureLocalStorage.getItem("token")
      )}`,
      type: "web",
    };

    // config.data = {
    //   data: CryptoJS.AES.encrypt(
    //     JSON.stringify(config.data),
    //     "visitorapp-key@12"
    //   ).toString(),
    // };

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  (response) => {
    // var bytes = CryptoJS.AES.decrypt(response?.data.data, "visitorapp-key@12");
    // var decryptedData = bytes.toString(CryptoJS.enc.Utf8);
    // response.data.data = JSON.parse(decryptedData);
    return response?.data;
  },
  (error) => {
    if (error.response.status === 403) {
      handleLogout();
      window.location.replace("/");
      // window.location.href("/");
    }
    if (error.response.status === 400) {
      window.location.replace("/evetnnotfound");
    }
    return Promise.reject(error);
  }
);

export default axios;
